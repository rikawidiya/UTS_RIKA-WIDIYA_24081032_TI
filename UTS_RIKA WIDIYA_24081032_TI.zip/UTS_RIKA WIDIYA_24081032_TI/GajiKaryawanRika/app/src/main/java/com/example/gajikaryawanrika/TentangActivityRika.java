package com.example.gajikaryawanrika;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TentangActivityRika extends AppCompatActivity {

    Button btnKembaliTentang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_rika);

        btnKembaliTentang =
                findViewById(R.id.btnKembaliTentang);

        btnKembaliTentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}