package com.example.gajikaryawanrika;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.util.Locale;

public class GajiActivityRika extends AppCompatActivity {

    EditText edtNik, edtNama, edtGajiPokok;
    EditText edtTunjanganJabatan, edtHariKerja;

    Button btnHitung;

    TextView tvMakan, tvTransport;
    TextView tvGajiKotor, tvGajiBersih;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaji_rika);

        edtNik = findViewById(R.id.edtNik);
        edtNama = findViewById(R.id.edtNama);
        edtGajiPokok = findViewById(R.id.edtGajiPokok);
        edtTunjanganJabatan = findViewById(R.id.edtTunjanganJabatan);
        edtHariKerja = findViewById(R.id.edtHariKerja);

        btnHitung = findViewById(R.id.btnHitung);

        tvMakan = findViewById(R.id.tvMakan);
        tvTransport = findViewById(R.id.tvTransport);
        tvGajiKotor = findViewById(R.id.tvGajiKotor);
        tvGajiBersih = findViewById(R.id.tvGajiBersih);

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitungGaji();
            }
        });
    }

    private void hitungGaji() {

        if (edtNik.getText().toString().isEmpty() ||
                edtNama.getText().toString().isEmpty() ||
                edtGajiPokok.getText().toString().isEmpty() ||
                edtTunjanganJabatan.getText().toString().isEmpty() ||
                edtHariKerja.getText().toString().isEmpty()) {

            Toast.makeText(this,
                    "Semua data harus diisi",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        double gajiPokok = Double.parseDouble(
                edtGajiPokok.getText().toString());

        double tunjanganJabatan = Double.parseDouble(
                edtTunjanganJabatan.getText().toString());

        int hariKerja = Integer.parseInt(
                edtHariKerja.getText().toString());


        double tunjanganMakan = hariKerja * 10000;


        double tunjanganTransport = hariKerja * 5000;


        double gajiKotor = gajiPokok +
                tunjanganJabatan +
                tunjanganMakan +
                tunjanganTransport;


        double pajak = gajiKotor * 0.10;


        double gajiBersih = gajiKotor - pajak;

        NumberFormat formatRupiah =
                NumberFormat.getCurrencyInstance(new Locale("id", "ID"));

        tvMakan.setText("Tunjangan Makan : " +
                formatRupiah.format(tunjanganMakan));

        tvTransport.setText("Tunjangan Transportasi : " +
                formatRupiah.format(tunjanganTransport));

        tvGajiKotor.setText("Gaji Kotor : " +
                formatRupiah.format(gajiKotor));

        tvGajiBersih.setText("Gaji Bersih : " +
                formatRupiah.format(gajiBersih));
    }
}